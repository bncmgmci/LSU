<?php 
   require "database.php";
   $host = "localhost";
   $user = "root";
   $pass = "";
   $database = "university";
   
   $connection = mysql_connect($host, $user, $pass)
   or die ("couldn't connect to database");
   mysql_select_db($database);
?>


<?php
// ******************* Creating initial database data **************
$query = "INSERT INTO users(userId,courseCode,name,surname,gender,email,userType,password)
		   VALUES (\"1\",\"555001\",\"Bobby\",\"Williams\",\"M\",\"admin@lsu.com\",\"Admin\",\"iamtheAdministrator1\")";
		$ret = mysql_query($query, $connection);
		if($ret)
		{
		   echo "Admin created";
		}
		else
		{
			echo "Could not create Admin account!";
		}
		?>


		<?php
        $query = "INSERT INTO users(userId,courseCode,name,surname,gender,email,userType,password)
		   VALUES (\"13\",\"555001\",\"Bobby\",\"Roberts\",\"M\",\"robert@lsu.com\",\"CM\",\"iambobby\")";
		$ret = mysql_query($query, $connection);
		if($ret)
		{
		   echo "Guest1 created";
		}
		else
		{
			echo "Could not create Guest1 account!";
		}
?>
<?php
$query = "INSERT INTO users(userId,courseCode,name,surname,gender,email,userType,password)
		   VALUES (\"2\",\"555001\",\"Just\",\"Visiting\",\"M\",\"guest1@lsu.com\",\"Guest\",\"iamjustvisiting1\")";
		$ret = mysql_query($query, $connection);
		if($ret)
		{
		   echo "Guest1 created";
		}
		else
		{
			echo "Could not create Guest1 account!";
		}
?>


<?php
$query = "INSERT INTO users(userId,courseCode,name,surname,gender,email,userType,password)
		   VALUES (\"3\",\"555001\",\"Just\",\"Visiting\",\"M\",\"guest2@lsu.com\",\"Guest\",\"iamjustvisiting2\")";
		$ret = mysql_query($query, $connection);
		if($ret)
		{
		   echo "Guest2 created";
		}
		else
		{
			echo "Could not create Guest2 account!";
		}
?>

<?php
$query = "INSERT INTO users(userId,courseCode,name,surname,gender,email,userType,password)
		   VALUES (\"4\",\"555001\",\"Just\",\"Visiting\",\"M\",\"guest3@lsu.com\",\"Guest\",\"iamjustvisiting3\")";
		$ret = mysql_query($query, $connection);
		if($ret)
		{
		   echo "Guest3 created";
		}
		else
		{
			echo "Could not create Guest3 account!";
		}
?>

<?php
$query = "INSERT INTO users(userId,courseCode,name,surname,gender,email,userType,password)
		   VALUES (\"5\",\"555001\",\"Jay\",\"Chibambo\",\"M\",\"jay@yahoo.com\",\"PVC\",\"iamjay\")";
		$ret = mysql_query($query, $connection);
		if($ret)
		{
		   echo "Jay account created";
		}
		else
		{
			echo "Could not create Jay account!";
		}
?>

<?php
$query = "INSERT INTO users(userId,courseCode,name,surname,gender,email,userType,password)
		   VALUES (\"6\",\"555001\",\"Monde\",\"Nkonde\",\"F\",\"monde@yahoo.com\",\"DLT\",\"iammonde\")";
		$ret = mysql_query($query, $connection);
		if($ret)
		{
		   echo "Monde account created";
		}
		else
		{
			echo "Could not create Monde account!";
		}
?>






v<?php
$query = "INSERT INTO users(userId,courseCode,name,surname,gender,email,userType,password)
		   VALUES (\"7\",\"555001\",\"Chris\",\"Malambo\",\"M\",\"chris@yahoo.com\",\"PVC\",\"iamchris\")";
		$ret = mysql_query($query, $connection);
		if($ret)
		{
		   echo "Chris account created";
		}
		else
		{
			echo "Could not create Chris account!";
		}
?>

<?php
$query = "INSERT INTO users(userId,courseCode,name,surname,gender,email,userType,password)
		   VALUES (\"8\",\"555001\",\"William\",\"James\",\"M\",\"william@yahoo.com\",\"DLT\",\"iamwilliam\")";
		$ret = mysql_query($query, $connection);
		if($ret)
		{
		   echo "William account created";
		}
		else
		{
			echo "Could not create William account!";
		}
?>

<?php
$query = "INSERT INTO users(userId,courseCode,name,surname,gender,email,userType,password)
		   VALUES (\"9\",\"555001\",\"Chikwe\",\"Muluwe\",\"M\",\"muluwe@yahoo.com\",\"PVC\",\"iamchikwe\")";
		$ret = mysql_query($query, $connection);
		if($ret)
		{
		   echo "Chikwe account created";
		}
		else
		{
			echo "Could not create Chikwe account!";
		}
?>

<?php
$query = "INSERT INTO users(userId,courseCode,name,surname,gender,email,userType,password)
		   VALUES (\"10\",\"555001\",\"Chitalu\",\"Ilunga\",\"M\",\"chichi@yahoo.com\",\"DLT\",\"iamchichi\")";
		$ret = mysql_query($query, $connection);
		if($ret)
		{
		   echo "Chitalu account created";
		}
		else
		{
			echo "Could not create Chitalu account!";
		}
?>


<?php
$query = "INSERT INTO users(userId,courseCode,name,surname,gender,email,userType,password)
		   VALUES (\"11\",\"555001\",\"Gloria\",\"Mutemi\",\"F\",\"gloria@yahoo.com\",\"PVC\",\"iamgloria\")";
		$ret = mysql_query($query, $connection);
		if($ret)
		{
		   echo "Gloria account created";
		}
		else
		{
			echo "Could not create Gloria account!";
		}
?>

<?php
$query = "INSERT INTO users(userId,courseCode,name,surname,gender,email,userType,password)
		   VALUES (\"12\",\"555001\",\"Joy\",\"Banda\",\"F\",\"joy@yahoo.com\",\"DLT\",\"iamjoy\")";
		$ret = mysql_query($query, $connection);
		if($ret)
		{
		   echo "Joy account created";
		}
		else
		{
			echo "Could not create Joy account!";
		}
?>









<?php
$query = "INSERT INTO users(userId,courseCode,name,surname,gender,email,userType,password)
		   VALUES (\"14\",\"222354\",\"James\",\"Judas\",\"M\",\"james@yahoo.com\",\"CL\",\"iamjames\")";
		$ret = mysql_query($query, $connection);
		if($ret)
		{
		   echo "James account created";
		}
		else
		{
			echo "Could not create James account!";
		}
?>

<?php
$query = "INSERT INTO users(userId,courseCode,name,surname,gender,email,userType,password)
		   VALUES (\"15\",\"222354\",\"Janet\",\"Jackson\",\"F\",\"janet@yahoo.com\",\"CM\",\"iamjackson\")";
		$ret = mysql_query($query, $connection);
		if($ret)
		{
		   echo "Janet account created";
		}
		else
		{
			echo "Could not create Janet account!";
		}
?>



<?php
$query = "INSERT INTO users(userId,courseCode,name,surname,gender,email,userType,password)
		   VALUES (\"16\",\"222687\",\"Subi\",\"Lanji\",\"F\",\"subi@yahoo.com\",\"CL\",\"iamsubi\")";
		$ret = mysql_query($query, $connection);
		if($ret)
		{
		   echo "Subi account created";
		}
		else
		{
			echo "Could not create Subi account!";
		}
?>

<?php
$query = "INSERT INTO users(userId,courseCode,name,surname,gender,email,userType,password)
		   VALUES (\"17\",\"222687\",\"Den\",\"Mark\",\"M\",\"den@yahoo.com\",\"CM\",\"iamden\")";
		$ret = mysql_query($query, $connection);
		if($ret)
		{
		   echo "Den account created";
		}
		else
		{
			echo "Could not create Den account!";
		}
?>


<?php
$query = "INSERT INTO users(userId,courseCode,name,surname,gender,email,userType,password)
		   VALUES (\"18\",\"222098\",\"Tom\",\"Thompson\",\"M\",\"tom@yahoo.com\",\"CL\",\"iamtom\")";
		$ret = mysql_query($query, $connection);
		if($ret)
		{
		   echo "Tom account created";
		}
		else
		{
			echo "Could not create Tom account!";
		}
?>

<?php
$query = "INSERT INTO users(userId,courseCode,name,surname,gender,email,userType,password)
		   VALUES (\"19\",\"222098\",\"Jerry\",\"Springer\",\"M\",\"jerry@yahoo.com\",\"CM\",\"iamjerry\")";
		$ret = mysql_query($query, $connection);
		if($ret)
		{
		   echo "Jerry account created";
		}
		else
		{
			echo "Could not create Jerry account!";
		}
?>











<?php
$query = "INSERT INTO users(userId,courseCode,name,surname,gender,email,userType,password)
		   VALUES (\"20\",\"333487\",\"Peter\",\"Banda\",\"M\",\"peter@yahoo.com\",\"CL\",\"iampeter\")";
		$ret = mysql_query($query, $connection);
		if($ret)
		{
		   echo "Peter account created";
		}
		else
		{
			echo "Could not create Peter account!";
		}
?>

<?php
$query = "INSERT INTO users(userId,courseCode,name,surname,gender,email,userType,password)
		   VALUES (\"21\",\"333487\",\"Isaiah\",\"Roc\",\"F\",\"isaiah@yahoo.com\",\"CM\",\"iamroc\")";
		$ret = mysql_query($query, $connection);
		if($ret)
		{
		   echo "Isaiah account created";
		}
		else
		{
			echo "Could not create Isaiah account!";
		}
?>



<?php
$query = "INSERT INTO users(userId,courseCode,name,surname,gender,email,userType,password)
		   VALUES (\"22\",\"444948\",\"Prince\",\"Charming\",\"F\",\"prince@yahoo.com\",\"CL\",\"iamprince\")";
		$ret = mysql_query($query, $connection);
		if($ret)
		{
		   echo "Prince account created";
		}
		else
		{
			echo "Could not create Prince account!";
		}
?>

<?php
$query = "INSERT INTO users(userId,courseCode,name,surname,gender,email,userType,password)
		   VALUES (\"23\",\"444948\",\"Shrek\",\"Zilla\",\"M\",\"shrek@yahoo.com\",\"CM\",\"iamshrek\")";
		$ret = mysql_query($query, $connection);
		if($ret)
		{
		   echo "Shreck account created";
		}
		else
		{
			echo "Could not create Shreck account!";
		}
?>


<?php
$query = "INSERT INTO users(userId,courseCode,name,surname,gender,email,userType,password)
		   VALUES (\"24\",\"555957\",\"Prince\",\"Williams\",\"M\",\"pwillie@yahoo.com\",\"CL\",\"iamwillie\")";
		$ret = mysql_query($query, $connection);
		if($ret)
		{
		   echo "Pwillie account created";
		}
		else
		{
			echo "Could not create Pwillie account!";
		}
?>

<?php
$query = "INSERT INTO users(userId,courseCode,name,surname,gender,email,userType,password)
		   VALUES (\"25\",\"555957\",\"Head\",\"Phones\",\"M\",\"head@yahoo.com\",\"CM\",\"iamhead\")";
		$ret = mysql_query($query, $connection);
		if($ret)
		{
		   echo "Head account created";
		}
		else
		{
			echo "Could not create Head account!";
		}
?>

<?php
$query = "INSERT INTO users(userId,courseCode,name,surname,gender,email,userType,password)
		   VALUES (\"26\",\"555756\",\"Chileshe\",\"Lesa\",\"M\",\"chileshe@yahoo.com\",\"CL\",\"iamchileshe\")";
		$ret = mysql_query($query, $connection);
		if($ret)
		{
		   echo "Chileshe account created";
		}
		else
		{
			echo "Could not create Chileshe account!";
		}
?>

<?php
$query = "INSERT INTO users(userId,courseCode,name,surname,gender,email,userType,password)
		   VALUES (\"27\",\"555756\",\"Patrick\",\"Lesa\",\"M\",\"patrick@yahoo.com\",\"CM\",\"iampatrick\")";
		$ret = mysql_query($query, $connection);
		if($ret)
		{
		   echo "Patrick account created";
		}
		else
		{
			echo "Could not create Patrick account!";
		}
?>













<?php
$query = "INSERT INTO faculty(facultyId,facultyName,PVC,DLT)
		   VALUES (\"22\",\"Finance\",\"5\",\"6\")";
		$ret = mysql_query($query, $connection);
		if($ret)
		{
		   echo "Finance Faculty created";
		}
		else
		{
			echo "Could not create Finance Faculty!";
		}
?>

<?php
$query = "INSERT INTO faculty(facultyId,facultyName,PVC,DLT)
		   VALUES (\"33\",\"Marketing\",\"7\",\"8\")";
		$ret = mysql_query($query, $connection);
		if($ret)
		{
		   echo "Marketing Faculty created";
		}
		else
		{
			echo "Could not create Marketing Faculty!";
		}
?>

<?php
$query = "INSERT INTO faculty(facultyId,facultyName,PVC,DLT)
		   VALUES (\"44\",\"Business\",\"9\",\"10\")";
		$ret = mysql_query($query, $connection);
		if($ret)
		{
		   echo "Business Faculty created";
		}
		else
		{
			echo "Could not create Business Faculty!";
		}
?>

<?php
$query = "INSERT INTO faculty(facultyId,facultyName,PVC,DLT)
		   VALUES (\"55\",\"I.T & Telecommunications\",\"11\",\"12\")";
		$ret = mysql_query($query, $connection);
		if($ret)
		{
		   echo "I.T Faculty created";
		}
		else
		{
			echo "Could not create I.T Faculty!";
		}
?>














<?php
$query = "INSERT INTO course(courseCode,courseName,facultyId,userId,userType,academicLevel,gradeAverage,comments,approvalStatus)
		   VALUES (\"222354\",\"ZICA\",\"22\",\"13\",\"CM\",\"none\",\"none%\",\"none\",\"none\")";
		$ret = mysql_query($query, $connection);
		if($ret)
		{
		   echo " ZICA course created";
		}
		else
		{
			echo "Could not create ZICA account!";
		}
?>


<?php
$query = "INSERT INTO course(courseCode,courseName,facultyId,userId,userType,academicLevel,gradeAverage,comments,approvalStatus)
		   VALUES (\"222687\",\"ACCA\",\"22\",\"13\",\"CM\",\"none\",\"none%\",\"none\",\"none\")";
		$ret = mysql_query($query, $connection);
		if($ret)
		{
		   echo " ACCA course created";
		}
		else
		{
			echo "Could not create ACCA account!";
		}
?>

<?php
$query = "INSERT INTO course(courseCode,courseName,facultyId,userId,userType,academicLevel,gradeAverage,comments,approvalStatus)
		   VALUES (\"222098\",\"CIMA\",\"22\",\"13\",\"CM\",\"none\",\"none%\",\"none\",\"none\")";
		$ret = mysql_query($query, $connection);
		if($ret)
		{
		   echo " CIMA course created";
		}
		else
		{
			echo "Could not create CIMA account!";
		}
?>


<?php
$query = "INSERT INTO course(courseCode,courseName,facultyId,userId,userType,academicLevel,gradeAverage,comments,approvalStatus)
		   VALUES (\"333487\",\"CIPS\",\"33\",\"13\",\"CM\",\"none\",\"none%\",\"none\",\"none\")";
		$ret = mysql_query($query, $connection);
		if($ret)
		{
		   echo " CIPS course created";
		}
		else
		{
			echo "Could not create CIPS account!";
		}
?>

<?php
$query = "INSERT INTO course(courseCode,courseName,facultyId,userId,userType,academicLevel,gradeAverage,comments,approvalStatus)
		   VALUES (\"444948\",\"ABE\",\"44\",\"13\",\"CM\",\"none\",\"none%\",\"none\",\"none\")";
		$ret = mysql_query($query, $connection);
		if($ret)
		{
		   echo " ABE course created";
		}
		else
		{
			echo "Could not create ABE account!";
		}
?>

<?php
$query = "INSERT INTO course(courseCode,courseName,facultyId,userId,userType,academicLevel,gradeAverage,comments,approvalStatus)
		   VALUES (\"555957\",\"NCC\",\"55\",\"13\",\"CM\",\"none\",\"none%\",\"none\",\"none\")";
		$ret = mysql_query($query, $connection);
		if($ret)
		{
		   echo " NCC course created";
		}
		else
		{
			echo "Could not create NCC account!";
		}
?>

<?php
$query = "INSERT INTO course(courseCode,courseName,facultyId,userId,userType,academicLevel,gradeAverage,comments,approvalStatus)
		   VALUES (\"555756\",\"BSC\",\"55\",\"13\",\"CM\",\"none\",\"none%\",\"none\",\"none\")";
		$ret = mysql_query($query, $connection);
		if($ret)
		{
		   echo " NCC course created";
		}
		else
		{
			echo "Could not create NCC account!";
		}
?>



