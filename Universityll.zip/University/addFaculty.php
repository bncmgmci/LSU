<!DOCTYPE html>
<?php
require "database.php";			
if (isset($_POST['add']))
{
	        $facultyId = $_POST['facultyId'];
			$facultyName = $_POST['facultyName'];
			$PVC = $_POST['PVC'];
			$DLT= $_POST['DLT'];
/*The following code adds a faculty*/
	mysql_query("INSERT INTO `faculty` (`facultyId`,`facultyName`, `PVC`, `DLT`) 
	VALUES ('$facultyId','$facultyName', '$PVC', '$DLT') ;")
	or die(mysql_error()); 
	
	
	header("Location: adminHome.php");
}
	
	session_start();
   if(!isset($_SESSION['sess_user']))
   {
	header("Location: adminHome.php");
	}
else
{
}
	
?>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
	
	
	<link rel="stylesheet" type="text/css" href="style.css"/>

	
    <title>LSU</title>

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/custom.css" rel="stylesheet">
</head>

<body>

    <!-- Navigation -->
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <!-- Logo and responsive toggle -->
            <div class="navbar-header">
                <a class="navbar-brand" href="#">
                	<span class="glyphicon glyphicon-fire"></span> 
                </a>
            </div>
            <!-- Navigation links -->
            <div class="collapse navbar-collapse" id="navbar">
                <ul class="nav navbar-nav">
                    <li class="active">
                        <a href="adminHome.php#faculty">Home</a>
                    </li>
                </ul>
		

        <h4 id="welcome">Welcome <?=$_SESSION['sess_user']?><br/><a href="logout.php">Logout</a></h4>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>

	<div class="jumbotron feature">
		<div class="container">
			<h1><span class="glyphicon glyphicon-equalizer"></span> LSK state University. </h1>
			<p>We do what others will not. That alone is Innovation.</p>
		</div>
	</div>

    <!-- Content -->
    <div class="container">

        <!-- Heading -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Welcome to LSK State University
                    <small>Zambia</small>
                </h1>
                </div>
        </div>
        <!-- /.row -->

        <!-- Feature Row -->
        <div class="row">
            
			<form method="POST" id="secondForm">
<h3>Add Faculty</h3><br>

                          
					<p>
	  	                <label for="facultyId">Faculty Id</label>
				        <input type="text" name="facultyId" id="signUp" placeholder="numeric data only">
				    </p>

                    <p>
	  	                <label for="facultyName">Faculty Name</label>
				        <input type="text" name="facultyName" id="signUp" >
				    </p>
                    <p>
	  	                <label for="PVC">Pro Vice Chancellor</label>
				        <input type="text" name="PVC" id="PVC" placeholder="numeric data only" >
				    </p>
                    <p>
	  	                <label for="DLT">Director of learning and quality</label>
				        <input type="text" name="DLT" id="DLT" placeholder="numeric data only" >
				    </p>					
					
                    <input type="submit" value="Add Faculty" name="add">
</form>

        </div>
		<br/>
        <!-- /.row -->

    </div>
    <!-- /.container -->
	
	<footer>
		<div class="footer-blurb">
			<div class="container">
				<div class="row">
					<div class="col-sm-4 footer-blurb-item">
						<h3><span class="glyphicon glyphicon-fire"></span> Areas of Expertise</h3>
						<p>We collaborate across disciplines, cultures and countries to solve global problems</p>
					</div>
					<div class="col-sm-4 footer-blurb-item">
						<h3><span class="glyphicon glyphicon-cloud-upload"></span> Service for business</h3>
						<p>We know the value of working together. Our expertise can help you achieve your business objectives </p>
					</div>
					<div class="col-sm-4 footer-blurb-item">
						<h3><span class="glyphicon glyphicon-leaf"></span> Support LSK State University</h3>
						<p>Your support helps our researchers and graduates to build a more progressive, responsible world </p>
					</div>
<div class="container">
        		<p>Terms &amp; Conditions | Privacy Policy | Contact</p>
        		<p>Copyright &copy; LskStateUniversity.com 2016 </p>
        	</div>
				</div>
				<!-- /.row -->	
			</div>
        </div>
      
	</footer>

	
    <!-- jQuery -->
    <script src="js/jquery-1.11.3.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
	
	<!-- IE10 viewport bug workaround -->
	<script src="js/ie10-viewport-bug-workaround.js"></script>
	
	<!-- Placeholder Images -->
	<script src="js/holder.min.js"></script>	
</body>

</html>
