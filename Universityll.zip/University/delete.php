<?php
require "database.php";

if(isset($_GET['deleteUser']))
{
/*The following code deletes a row in the users table of the database*/
$query = mysql_query("DELETE FROM `users` WHERE `userId` = '{$_GET['deleteUser']}'")or die('Error : ' . mysql_error());

header("Location: adminHome.php");
exit;
}

if(isset($_GET['deleteCourse']))
{
/*The following code deletes a row in the course table of the database*/
$query = mysql_query("DELETE FROM `course` WHERE `courseCode` = '{$_GET['deleteCourse']}'")or die('Error : ' . mysql_error());

header("Location: adminHome.php");
exit;
}
if(isset($_GET['deleteFaculty']))
{
/*The following code deletes a row in the course table of the database*/
$query = mysql_query("DELETE FROM `faculty` WHERE `facultyId` = '{$_GET['deleteFaculty']}'")or die('Error : ' . mysql_error());

header("Location: adminHome.php");
exit;
}
?>