<!DOCTYPE html>
<?php
require "database.php";
?>
	
<?php
if(isset($_POST['logIn'])){
	$email = $_POST['email'];
	$password = $_POST['password'];

	$query = mysql_query("SELECT * FROM `users` WHERE `email`='$email' AND `password`='$password'");
	$numrows = mysql_num_rows($query);
	
	if($numrows != 0){
		while($row = mysql_fetch_assoc($query)){
			$sUser = $row['name'];
			$dbEmail = $row['email'];
			$dbPassword = $row['password'];
		    $dbuserType=$row['userType'];
		}
		
		    if($email == $dbEmail && $password == $dbPassword && $dbuserType == 'Admin'){
		
			session_start();
			$_SESSION['sess_user'] = $sUser;
			header("Location: adminHome.php");		
			}
			
			if($email == $dbEmail && $password == $dbPassword && $dbuserType == 'Guest'){
		
			session_start();
			$_SESSION['sess_user'] = $sUser;
			header("Location: guestHome.php");		
			}
			
			if($email == $dbEmail && $password == $dbPassword && $dbuserType == 'CL'){
		

			session_start();
			$_SESSION['sess_user'] = $sUser;
			header("Location: clHome.php");		
			}
			
			if($email == $dbEmail && $password == $dbPassword && $dbuserType == 'CM'){
		

			session_start();
			$_SESSION['sess_user'] = $sUser;
			header("Location: cmHome.php");		
			}
			
			if($email == $dbEmail && $password == $dbPassword && $dbuserType == 'DLT'){
		

			session_start();
			$_SESSION['sess_user'] = $sUser;
			header("Location: dltHome.php");		
			}
			
			if($email == $dbEmail && $password == $dbPassword && $dbuserType == 'PVC'){
		
			session_start();
			$_SESSION['sess_user'] = $sUser;
			header("Location: pvcHome.php");		
			}
				
	} else {
		echo "<script>window.alert('Wrong User name or Password');</script>";
	}	
}

?>

<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>LSU</title>

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/custom.css" rel="stylesheet">
</head>

<body>

    <!-- Navigation -->
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <!-- Logo and responsive toggle -->
            <div class="navbar-header">
                <a class="navbar-brand" href="#">
                	<span class="glyphicon glyphicon-fire"></span> 
                </a>
            </div>
            <!-- Navigation links -->
            <div class="collapse navbar-collapse" id="navbar">
                <ul class="nav navbar-nav">
                    <li class="active">
                        <a href="#">Home</a>
                    </li>
                    <li>
					<!-- List of all courses -->
                        <a href="#study">Study with us</a>
                    </li>
                    <li>
					<!-- Will leave lecturer details here, email, number etc -->
                        <a href="#engage">Engage</a>
						 
                    </li>
					<li>
					<!-- A space for lecturers to leave notes and updates for all other lecturers (comm hub) -->
                        <a href="#activity">Activities</a>
						 
                    </li>

                    
    </li>
                </ul>
	
        
        <form method="POST" id="secondForm"><!-- log in form -->
		<br/>
          <fieldset id="inputs">
            <input id="userName" type="email" name="email" placeholder="Your email address" required>   
            <input id="password" type="password" name="password" placeholder="Password" required>
          </fieldset>
          <fieldset id="actions">
            <input type="submit" id="logIn" value="Log in" name="logIn"> 
          </fieldset>
        </form>	
		
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>

	<div class="jumbotron feature">
		<div class="container">
			<h1><span class="glyphicon glyphicon-equalizer"></span> LSK state University. </h1>
			<p>We do what others will not. That alone is Innovation.</p>
		</div>
	</div>

    <!-- Content -->
    <div class="container">

        <!-- Heading -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Welcome to LSK State University
                    <small>Zambia</small>
                </h1>
                <p>Established in 1883, LSK State University is a public-spirited institution that makes distinctive contributions to society in research, learning and teaching and engagement. It’s consistently ranked among the leading universities in the world, with international rankings of world universities placing it as number 3 in Zambia and number 33 in the world (Times Higher Education World University Rankings 2015-2016).</p>
            </div>
        </div>
        <!-- /.row -->

        <!-- Feature Row -->
        <div class="row">
            <article class="col-md-4 article-intro">
                    <img class="img-responsive img-rounded" src="images/main.jpg" alt="">
                <a name="user">
				<h3>
                    Study with us
                </h3>
				</a>
                <p>To compete on the world stage, you need a world-standard education. At LSK State University, you’ll gain an internationally recognised degree that will open doors to an outstanding future.</p>
            </article>
            <article class="col-md-4 article-intro">
                    <img class="img-responsive img-rounded" src="images/Diverse.jpg" alt="">                
				<a name="user">
				<h3>
                    Engage
                </h3>
				</a>
                <p>Since its founding, the University has held engagement as central to its values and purpose, ensuring that its ethos as a public spirited institution finds expression through all of its endeavours.</p>
            </article>

            <article class="col-md-4 article-intro">
                    <img class="img-responsive img-rounded" src="images/images.jpg" alt="">
                <a name="activity">
				<h3>
                    Campus Activities
                </h3>
				</a>
                <p>As an LSK State University student, you can get involved in the many campus activities on offer, enjoy amazing new experiences and make lifelong friends along the way. Our students explain why they love studying and living in the heart of LSK State University.</p>
            </article>
        </div>
        <!-- /.row -->

    </div>
    <!-- /.container -->
	
	<footer>
		<div class="footer-blurb">
			<div class="container">
				<div class="row">
					<div class="col-sm-4 footer-blurb-item">
						<h3><span class="glyphicon glyphicon-fire"></span> Areas of Expertise</h3>
						<p>We collaborate across disciplines, cultures and countries to solve global problems</p>
					</div>
					<div class="col-sm-4 footer-blurb-item">
						<h3><span class="glyphicon glyphicon-cloud-upload"></span> Service for business</h3>
						<p>We know the value of working together. Our expertise can help you achieve your business objectives </p>
					</div>
					<div class="col-sm-4 footer-blurb-item">
						<h3><span class="glyphicon glyphicon-leaf"></span> Support LSK State University</h3>
						<p>Your support helps our researchers and graduates to build a more progressive, responsible world </p>
					</div>
                <div class="container">
        		<p>Terms &amp; Conditions | Privacy Policy | Contact</p>
        		<p>Copyright &copy; LskStateUniversity.com 2016 </p>
        	</div>
				</div>
				<!-- /.row -->	
			</div>
        </div>
        
	</footer>

	
    <!-- jQuery -->
    <script src="js/jquery-1.11.3.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
	
	<!-- IE10 viewport bug workaround -->
	<script src="js/ie10-viewport-bug-workaround.js"></script>
	
	<!-- Placeholder Images -->
	<script src="js/holder.min.js"></script>
</body>
</html>
