<!DOCTYPE html>
<?php
require "database.php";


 session_start();
   if(!isset($_SESSION['sess_user']))
   {
	header("Location: clHome.php");
	}
else
{
}
?>

<?php
/*The following code sends a CMR email*/
   if (isset($_POST['post']))
   {   
   $query = mysql_query("SELECT * FROM `users` WHERE `userType`='CM'");
	$numrows = mysql_num_rows($query);
   
   if($numrows != 0){
		while($row = mysql_fetch_assoc($query)){
			$dbEmail = $row['email'];
	        $courseName = htmlentities($_POST['courseName']);
	        $academicLevel = htmlentities($_POST['academicLevel']);
	        $gradeAverage = htmlentities($_POST['gradeAverage']);
	}
	
	
	   mysql_query("UPDATE `course` SET 
	`academicLevel` = '$academicLevel',
	`gradeAverage` = '$gradeAverage',
	`approvalStatus` = 'pending' WHERE `courseCode` = '$courseName';")
				or die(mysql_error()); 
	echo "Course Updated!";
			
	 
            $to = $dbEmail;
			$subject = 'CMR Approval';
			$body ='Course Name:' . $courseName . '    ' . 'Academic Level:' . $academicLevel  . '    ' . 
			'Grade Average:' . $gradeAverage . '    ' .  'Comments:' . $comments;
			$headers ='From: admin@isu.com';
			if (mail($to, $subject, $body, $headers)) {
			
			
			echo "<script Language='javascript' type='text/javascript'>
			alert('Email sent...');
			</script>";
		}else{
			echo "<script Language='javascript' type='text/javascript'>
			alert('Failed to send email.');
			</script>";}
	

	
	}
	header("Location: clHome.php");
	}
	
?>
	
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
	
	
	<link rel="stylesheet" type="text/css" href="style.css"/>

    <title>LSU</title>

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/custom.css" rel="stylesheet">
</head>

<body>

    <!-- Navigation -->
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <!-- Logo and responsive toggle -->
            <div class="navbar-header">
                <a class="navbar-brand" href="#">
                	<span class="glyphicon glyphicon-fire"></span> 
                </a>
            </div>
            <!-- Navigation links -->
            <div class="collapse navbar-collapse" id="navbar">
                <ul class="nav navbar-nav">
                    <li class="active">
                        <a href="#">Home</a>
                    </li>
                </ul>	
        
        <h4 id="welcome">Welcome <?=$_SESSION['sess_user']?><br/><a href="logout.php">Logout</a></h4>
	
		
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>

	<div class="jumbotron feature">
		<div class="container">
			<h1><span class="glyphicon glyphicon-equalizer"></span> LSK state University. </h1>
			<p>We do what others will not. That alone is Innovation.</p>
		</div>
	</div>

    <!-- Content -->
    <div class="container">

        <!-- Heading -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Welcome to LSK State University
                    <small>Zambia</small>
                </h1>
                </div>
        </div>
        <!-- /.row -->

        <!-- Feature Row -->
        <div class="row">
            
			  
			  
			 <h3>Course Monitoring Reports</h3>
			 <div class="CSS_Table_Example">
					<?php
   
   echo "<table>
			
					<tr>
						<th >Course Name</th>
						<th >Academic Level</th>
						<th >Grade Average</th>
						<th >Comment</th>
					</tr>
			</table>";
			
			
   $query = "SELECT * FROM `course` WHERE `approvalStatus` = 'pending'";
   if($query_run = mysql_query($query))
	{
   
   if(mysql_num_rows($query_run) == NULL )
	    {
			echo "<h3 id='importantMessage'>No results found.</h3>";
			
		}else
		{
		
		While($query_row = mysql_fetch_assoc($query_run))
		{
		
			$courseName = $query_row['courseName'];
			$academicLevel= $query_row['academicLevel'];
			$gradeAverage= $query_row['gradeAverage'];
			$comments= $query_row['comments'];
		
			
			echo "<table>
			
					<tr>						
						<td >" . $courseName . "</td>
						<td >" . $academicLevel . "</td>
						<td >" . $gradeAverage . "</td>
						<td >" . $comments . "</td>
					</tr>
				  </table>";  
		}
		}
	}else
	{
		echo "<h4 id='importantMessage'>Querry Failed!</h4>";
	}
   
   
   ?>
   </div>
			  
			  
			  <form method="POST" id="secondForm">
<h3>Send Report</h3><br>

                          
					<p class="cmr">
				        <label for="courseName">Course</label>
				        <select name="courseName">
                          <option value="222098">CIMA</option>
                          <option value="222354">ZICA</option>
                          <option value="222687">ACCA</option>
                          <option value="333487">CIPS</option>
                          <option value="444948">ABE</option>
						  <option value="555756">BSC</option>
						  <option value="555957">NCC</option>
                       </select> 
				    </p>
					<p class="cmr">
				        <label for="academicLevel">Academic Level</label>
				        <select name="academicLevel">
                          <option value="beginner">Beginner</option>
                          <option value="intermediate">Intermediate</option>
						  <option value="intermediate">Advanced</option>
						  <option value="graduate">Graduate</option>
                       </select> 
				    </p>
					<p class="cmr">
				        <label for="gradeAverage">Grade Average</label>
				        <select name="gradeAverage">
                          <option value="0%">0%</option>
						  <option value="1%">1%</option>
                          <option value="2%">2%</option>
                          <option value="3%">3%</option>
                          <option value="4%">4%</option>
                          <option value="5%">5%</option>
						  <option value="6%">6%</option>
                          <option value="7%">7%</option>
                          <option value="8%">8%</option>
                          <option value="9%">9%</option>
                          <option value="10%">10%</option>
						  <option value="11%">11%</option>
                          <option value="12%">12%</option>
                          <option value="13%">13%</option>
                          <option value="14%">14%</option>
                          <option value="15%">15%</option>
						  <option value="16%">16%</option>
                          <option value="17%">17%</option>
                          <option value="18%">18%</option>
                          <option value="19%">19%</option>
                          <option value="20%">20%</option>
						  <option value="21%">21%</option>
                          <option value="22%">22%</option>
                          <option value="23%">23%</option>
                          <option value="24%">24%</option>
                          <option value="25%">25%</option>
						  <option value="26%">26%</option>
                          <option value="27%">27%</option>
                          <option value="28%">28%</option>
                          <option value="29%">29%</option>
                          <option value="30%">30%</option>
						  <option value="31%">31%</option>
                          <option value="32%">32%</option>
                          <option value="33%">33%</option>
                          <option value="34%">34%</option>
                          <option value="35%">35%</option>
						  <option value="36%">36%</option>
                          <option value="37%">37%</option>
                          <option value="38%">38%</option>
                          <option value="39%">39%</option>
                          <option value="40%">40%</option>
						  <option value="41%">41%</option>
                          <option value="42%">42%</option>
                          <option value="43%">43%</option>
                          <option value="44%">44%</option>
                          <option value="45%">45%</option>
						  <option value="46%">46%</option>
                          <option value="47%">47%</option>
                          <option value="48%">48%</option>
                          <option value="49%">49%</option>
                          <option value="50%">50%</option>
						  <option value="51%">51%</option>
                          <option value="52%">52%</option>
                          <option value="53%">53%</option>
                          <option value="54%">54%</option>
                          <option value="55%">55%</option>
						  <option value="56%">56%</option>
                          <option value="57%">57%</option>
                          <option value="58%">58%</option>
                          <option value="59%">59%</option>
                          <option value="60%">60%</option>
						  <option value="61%">61%</option>
                          <option value="62%">62%</option>
                          <option value="63%">63%</option>
                          <option value="64%">64%</option>
                          <option value="65%">65%</option>
						  <option value="66%">66%</option>
                          <option value="67%">67%</option>
                          <option value="68%">68%</option>
                          <option value="69%">69%</option>
                          <option value="70%">70%</option>
						  <option value="71%">71%</option>
                          <option value="72%">72%</option>
                          <option value="73%">73%</option>
                          <option value="74%">74%</option>
                          <option value="75%">75%</option>
						  <option value="76%">76%</option>
                          <option value="77%">77%</option>
                          <option value="78%">78%</option>
                          <option value="79%">79%</option>
                          <option value="80%">80%</option>
						  <option value="81%">81%</option>
                          <option value="82%">82%</option>
                          <option value="83%">83%</option>
                          <option value="84%">84%</option>
                          <option value="85%">85%</option>
						  <option value="86%">86%</option>
                          <option value="87%">87%</option>
                          <option value="88%">88%</option>
                          <option value="89%">89%</option>
                          <option value="90%">90%</option>
						  <option value="91%">91%</option>
                          <option value="92%">92%</option>
                          <option value="93%">93%</option>
                          <option value="94%">94%</option>
                          <option value="95%">95%</option>
						  <option value="96%">96%</option>
                          <option value="97%">97%</option>
                          <option value="98%">98%</option>
                          <option value="99%">99%</option>
                          <option value="100%">100%</option>
                       </select> 
				    </p>
                    
                    <input type="submit" value="Post" name="post">
					</form>
					
					
					

        </div>
        <!-- /.row -->

    </div><br/>
    <!-- /.container -->
	
	<footer>
		<div class="footer-blurb">
			<div class="container">
				<div class="row">
					<div class="col-sm-4 footer-blurb-item">
						<h3><span class="glyphicon glyphicon-fire"></span> Areas of Expertise</h3>
						<p>We collaborate across disciplines, cultures and countries to solve global problems</p>
					</div>
					<div class="col-sm-4 footer-blurb-item">
						<h3><span class="glyphicon glyphicon-cloud-upload"></span> Service for business</h3>
						<p>We know the value of working together. Our expertise can help you achieve your business objectives </p>
					</div>
					<div class="col-sm-4 footer-blurb-item">
						<h3><span class="glyphicon glyphicon-leaf"></span> Support LSK State University</h3>
						<p>Your support helps our researchers and graduates to build a more progressive, responsible world </p>
					</div>
<div class="container">
        		<p>Terms &amp; Conditions | Privacy Policy | Contact</p>
        		<p>Copyright &copy; LskStateUniversity.com 2016 </p>
        	</div>
				</div>
				<!-- /.row -->	
			</div>
        </div>
      
	</footer>

	
    <!-- jQuery -->
    <script src="js/jquery-1.11.3.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
	
	<!-- IE10 viewport bug workaround -->
	<script src="js/ie10-viewport-bug-workaround.js"></script>
	
	<!-- Placeholder Images -->
	<script src="js/holder.min.js"></script>
	
	
	

	
	
</body>

</html>
