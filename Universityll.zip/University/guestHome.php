<!DOCTYPE html>
<?php
require "database.php";


 session_start();
   if(!isset($_SESSION['sess_user']))
   {
	header("Location: guestHome.php");
	}
else
{
}
?>

<?php
/*The following code sends a CMR email*/
   if (isset($_POST['post']))
   {   
   $query = mysql_query("SELECT * FROM `users` WHERE `userType`='CM'");
	$numrows = mysql_num_rows($query);
   
   if($numrows != 0){
		while($row = mysql_fetch_assoc($query)){
			$dbEmail = $row['email'];
	        $courseName = htmlentities($_POST['courseName']);
	        $academicLevel = htmlentities($_POST['academicLevel']);
	        $gradeAverage = htmlentities($_POST['gradeAverage']);
	        $comments = htmlentities($_POST['comments']);
	}
	
	
	   mysql_query("UPDATE `course` SET 
	`academicLevel` = '$academicLevel',
	`gradeAverage` = '$gradeAverage',
	`comments` = '$comments',
	`approvalStatus` = 'pending' WHERE `courseCode` = '$courseName';")
				or die(mysql_error()); 
	echo "Course Updated!";
	
	
	if (empty($_POST["comments"]))
			{$error = "<script> window.alert('Subject cannot be left blank!');</script>";
			 echo "<h2 id='errorMessage'>$error </h2>";
			 die();
			}
			
			
			
	 
            $to = $dbEmail;
			$subject = 'CMR Approval';
			$body ='Course Name:' . $courseName . '    ' . 'Academic Level:' . $academicLevel  . '    ' . 
			'Grade Average:' . $gradeAverage . '    ' .  'Comments:' . $comments;
			$headers ='From: admin@isu.com';
			if (mail($to, $subject, $body, $headers)) {
			
			
			echo "<script Language='javascript' type='text/javascript'>
			alert('Email sent...');
			</script>";
		}else{
			echo "<script Language='javascript' type='text/javascript'>
			alert('Failed to send email.');
			</script>";}
	

	
	}
	}
?>
	
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
	
	
	<link rel="stylesheet" type="text/css" href="style.css"/>

    <title>LSU</title>

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/custom.css" rel="stylesheet">
</head>

<body>

    <!-- Navigation -->
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <!-- Logo and responsive toggle -->
            <div class="navbar-header">
                <a class="navbar-brand" href="#">
                	<span class="glyphicon glyphicon-fire"></span> 
                </a>
            </div>
            <!-- Navigation links -->
            <div class="collapse navbar-collapse" id="navbar">
                <ul class="nav navbar-nav">
                    <li class="active">
                        <a href="#">Home</a>
                    </li>
                </ul>	
        
        <h4 id="welcome">Welcome <?=$_SESSION['sess_user']?><br/><a href="logout.php">Logout</a></h4>
	
		
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>

	<div class="jumbotron feature">
		<div class="container">
			<h1><span class="glyphicon glyphicon-equalizer"></span> LSK state University. </h1>
			<p>We do what others will not. That alone is Innovation.</p>
		</div>
	</div>

    <!-- Content -->
    <div class="container">

        <!-- Heading -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Welcome to LSK State University
                    <small>Zambia</small>
                </h1>
                </div>
        </div>
        <!-- /.row -->

        <!-- Feature Row -->
        <div class="row">
            	  
			  <h3>Course Monitoring Reports</h3><br>

            <div class="CSS_Table_Example">             
					<?php
   
   echo "<table>
			
					<tr>
						<th >Course Name</th>
						<th >Academic Level</th>
						<th >Grade Average</th>
						<th >Comment</th>
					</tr>
			</table>";
			
			
   $query = "SELECT * FROM `course` WHERE approvalStatus = 'approved'";
   if($query_run = mysql_query($query))
	{
   
   if(mysql_num_rows($query_run) == NULL )
	    {
			echo "<h3 id='importantMessage'>No results found.</h3>";
			
		}else
		{
		
		While($query_row = mysql_fetch_assoc($query_run))
		{
		
			$courseName = $query_row['courseName'];
			$academicLevel= $query_row['academicLevel'];
			$gradeAverage= $query_row['gradeAverage'];
			$comments= $query_row['comments'];
		
			
			echo "<table>
			
					<tr>						
						<td >" . $courseName . "</td>
						<td >" . $academicLevel . "</td>
						<td >" . $gradeAverage . "</td>
						<td >" . $comments . "</td>
					</tr>
				  </table>";  
		}
		}
	}else
	{
		echo "<h4 id='importantMessage'>Querry Failed!</h4>";
	}
   
   
   ?>
   </div>
					
					

        </div>
        <!-- /.row -->

    </div>
    <!-- /.container -->
	<br/>
	
	<footer>
		<div class="footer-blurb">
			<div class="container">
				<div class="row">
					<div class="col-sm-4 footer-blurb-item">
						<h3><span class="glyphicon glyphicon-fire"></span> Areas of Expertise</h3>
						<p>We collaborate across disciplines, cultures and countries to solve global problems</p>
					</div>
					<div class="col-sm-4 footer-blurb-item">
						<h3><span class="glyphicon glyphicon-cloud-upload"></span> Service for business</h3>
						<p>We know the value of working together. Our expertise can help you achieve your business objectives </p>
					</div>
					<div class="col-sm-4 footer-blurb-item">
						<h3><span class="glyphicon glyphicon-leaf"></span> Support LSK State University</h3>
						<p>Your support helps our researchers and graduates to build a more progressive, responsible world </p>
					</div>
<div class="container">
        		<p>Terms &amp; Conditions | Privacy Policy | Contact</p>
        		<p>Copyright &copy; LskStateUniversity.com 2016 </p>
        	</div>
				</div>
				<!-- /.row -->	
			</div>
        </div>
      
	</footer>

	
    <!-- jQuery -->
    <script src="js/jquery-1.11.3.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
	
	<!-- IE10 viewport bug workaround -->
	<script src="js/ie10-viewport-bug-workaround.js"></script>
	
	<!-- Placeholder Images -->
	<script src="js/holder.min.js"></script>
	
	
	

	
	
</body>

</html>
