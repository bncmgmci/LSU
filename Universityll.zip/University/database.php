<?php
$error = "Could not Connect!";

$mysql_host = "localhost";
$mysql_user = "root";
$mysql_pass = "";
$mysql_db = "university";
	
$connect = mysql_connect($mysql_host, $mysql_user, $mysql_pass);  

	
if (!$connect)
{
die ($error) ;
}	

$database = mysql_select_db("university",$connect);

if (!$database)
{

	$createQuery = "CREATE DATABASE  `university`";
	
	if(mysql_query($createQuery))
	{
	
	echo "Database created";

	} else 
	{
	echo "Database has not been created";
	}

}	

// ******************* CREATING TABLES **************
$database = mysql_select_db("university",$connect);

//Users Table
$createUsers="CREATE TABLE IF NOT EXISTS users(	
		userId  int(5) NOT NULL AUTO_INCREMENT,
		courseCode int(8) NOT NULL,
		name varchar(15) NOT NULL,
		surname varchar(15) NOT NULL,
		gender varchar (6) NOT NUll,
		email varchar (30),
		userType varchar(8) NOT NULL,
		password varchar (20) NOT NULL,
        PRIMARY KEY (userId))";




// Faculty Table
$createFaculty="CREATE TABLE IF NOT EXISTS faculty(
		facultyId int (5) NOT NULL AUTO_INCREMENT,
		facultyName varchar (15) NOT NULL,		
		PVC int (5) NOT NULL,
		DLT int (5) NOT NULL,
        PRIMARY KEY (facultyId),
		FOREIGN KEY (PVC) REFERENCES users (userId),
        FOREIGN KEY (DLT) REFERENCES users (userId))";
		




//Course Table
$createCourse="CREATE TABLE IF NOT EXISTS course(	
		courseCode  varchar(7),
		courseName varchar(15) NOT NULL,
		facultyId int(5) NOT NULL,
		userId int(5) NOT NULL,
		userType varchar(8) NOT NULL,
		academicLevel varchar(15),
		gradeAverage varchar(5),
		comments varchar(50),
		approvalStatus varchar (15),
        PRIMARY KEY (courseCode),	
        FOREIGN KEY (facultyId) REFERENCES faculty (facultyId),
        FOREIGN KEY (userId) REFERENCES users (userId))";
		
		
		
		
		
// ******************* CHECKING IF TABLES HAVE BEEN CREATED **************
if (mysql_query($createUsers,$connect))
{ 
   
}
else
{
   echo "<p>Error creating users table: " . mysql_error(); + "</p>";
}   




if (mysql_query($createFaculty,$connect))
{ 
  
}
else
{
   echo "<p>Error creating Faculty table: " . mysql_error(); + "</p>";
}





if (mysql_query($createCourse,$connect))
{ 
  
}
else
{
   echo "<p>Error creating course table: " . mysql_error(); + "</p>";
}
