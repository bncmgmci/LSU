<?php
require "database.php";

if(isset($_GET['approvalStatus']))
{
/*The following code approves a CMR in the course table of the database*/

mysql_query("UPDATE `course` SET 
	`approvalStatus` = 'approved'
   	 WHERE `courseCode` = '{$_GET['approvalStatus']}'")or die('Error : ' . mysql_error());

/*The following code sends a CMR email*/
    
   $query = mysql_query("SELECT * FROM `course` WHERE `courseCode`='{$_GET['approvalStatus']}'");
	$numrows = mysql_num_rows($query);
   
   if($numrows != 0)
   {
		while($row = mysql_fetch_assoc($query))
		{
			$dbfacultyId = $row['facultyId'];
	        $dbcourseName = $row['courseName'];
	        $dbacademicLevel = $row['academicLevel'];
	        $dbgradeAverage = $row['gradeAverage'];
	        $dbcomments = $row['comments'];
		
		$query2 = mysql_query("SELECT * FROM `faculty` WHERE `facultyId`='$dbfacultyId'");
	$numrows = mysql_num_rows($query2);
	
	
	       if($numrows != 0)
		   {
		   while($row2 = mysql_fetch_assoc($query2))
		   {
	           $dbPVC = $row2['PVC'];
	           $dbDLT = $row2['DLT'];
			   
			   $query3 = mysql_query("SELECT * FROM `users` WHERE `userId`='$dbPVC'");
	$numrows = mysql_num_rows($query3);
			   
			   if($numrows != 0)
		   {
		   while($row3 = mysql_fetch_assoc($query3))
		   {
	           $dbEmail = $row3['email'];
			   
			   
			   $to = $dbEmail;
			$subject = 'Approved CMR';
			$body ='Course Name:' . $dbcourseName . '    ' . 'Academic Level:' . $dbacademicLevel  . '    ' . 
			'Grade Average:' . $dbgradeAverage . '    ' .  'Comments:' . $dbcomments;
			$headers ='From: admin@isu.com';
			if (mail($to, $subject, $body, $headers)) {
			
			
			echo "<script Language='javascript' type='text/javascript'>
			alert('Email sent to PVC');
			</script>";
		}else{
			echo "<script Language='javascript' type='text/javascript'>
			alert('Failed to send email to PVC');
			</script>";}
			
			$query3 = mysql_query("SELECT * FROM `users` WHERE `userId`='$dbDLT'");
	$numrows = mysql_num_rows($query3);
			   
			   if($numrows != 0)
		   {
		   while($row3 = mysql_fetch_assoc($query3))
		   {
	           $dbEmail = $row3['email'];
			   
			   
			   $to = $dbEmail;
			$subject = 'Approved CMR';
			$body ='Course Name:' . $dbcourseName . '    ' . 'Academic Level:' . $dbacademicLevel  . '    ' . 
			'Grade Average:' . $dbgradeAverage . '    ' .  'Comments:' . $dbcomments;
			$headers ='From: admin@isu.com';
			if (mail($to, $subject, $body, $headers)) {
			
			
			echo "<script Language='javascript' type='text/javascript'>
			alert('Email sent to DLT');
			</script>";
		}else{
			echo "<script Language='javascript' type='text/javascript'>
			alert('Failed to send email to DLT');
			</script>";}
			   }} 
			}} 
			}
			}
		}		
	}
}
	header("Location: cmHome.php");
exit;
?>